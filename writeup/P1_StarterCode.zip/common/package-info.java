/** Classes common between all filesystem components.
 */
package common;
