/** Filesystem applications.

    <p>
    Filesystem applications provide ways to start naming and storage servers
    from the command line.
 */
package apps;
